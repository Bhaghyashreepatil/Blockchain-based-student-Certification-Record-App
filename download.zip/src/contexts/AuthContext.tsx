
"use client";

import type { User, Role } from '@/types';
import { useRouter } from 'next/navigation';
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useToast } from "@/hooks/use-toast";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, role: Role) => Promise<void>; // Simplified login
  signup: (email: string, role: Role, name?: string) => Promise<void>; // Simplified signup
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users database
const mockUsers: User[] = [
  { id: 'student1', email: 'student@example.com', role: 'student', name: 'Student User' },
  { id: 'uni1', email: 'university@example.com', role: 'university', name: 'University Admin' },
];

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    // Simulate checking for an existing session
    const storedUser = localStorage.getItem('blockcertify-user');
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      // Ensure the role is valid after potential type changes
      if (parsedUser.role === 'student' || parsedUser.role === 'university') {
         setUser(parsedUser);
      } else {
        // If user had an old 'employer' role, log them out
        localStorage.removeItem('blockcertify-user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (email: string, role: Role) => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    const foundUser = mockUsers.find(u => u.email === email && u.role === role);
    
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('blockcertify-user', JSON.stringify(foundUser));
      toast({ title: "Login Successful", description: `Welcome back, ${foundUser.name || foundUser.email}!` });
      router.push(`/${foundUser.role}/dashboard`);
    } else {
      toast({ title: "Login Failed", description: "Invalid email or role.", variant: "destructive" });
    }
    setLoading(false);
  };

  const signup = async (email: string, role: Role, name?: string) => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    if (mockUsers.find(u => u.email === email)) {
      toast({ title: "Signup Failed", description: "Email already in use.", variant: "destructive" });
      setLoading(false);
      return;
    }
    const newUser: User = { id: `user-${Date.now()}`, email, role, name };
    mockUsers.push(newUser); // Add to mock DB
    setUser(newUser);
    localStorage.setItem('blockcertify-user', JSON.stringify(newUser));
    toast({ title: "Signup Successful", description: `Welcome, ${newUser.name || newUser.email}!` });
    router.push(`/${newUser.role}/dashboard`);
    setLoading(false);
  };

  const logout = async () => {
    setUser(null);
    localStorage.removeItem('blockcertify-user');
    toast({ title: "Logged Out", description: "You have been successfully logged out." });
    router.push('/login');
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
