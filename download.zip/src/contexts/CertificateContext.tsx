
"use client";

import type { Certificate, CertificateStatus } from '@/types';
import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from './AuthContext';

interface CertificateContextType {
  certificates: Certificate[];
  loading: boolean;
  addCertificate: (data: Omit<Certificate, 'id' | 'status' | 'studentId' | 'studentEmail' | 'qrCodeData' | 'blockchainHash'>) => Promise<void>;
  updateCertificateStatus: (id: string, status: CertificateStatus, verificationNotes?: string, aiSuggestions?: string) => Promise<void>;
  getCertificateById: (id: string) => Certificate | undefined;
  getCertificatesByStudent: (studentId: string) => Certificate[];
  getPendingCertificates: () => Certificate[];
}

const CertificateContext = createContext<CertificateContextType | undefined>(undefined);

// Mock certificate data
const initialCertificates: Certificate[] = [
  {
    id: 'cert1',
    studentId: 'student1',
    studentEmail: 'student@example.com',
    certificateName: 'Bachelor of Science in Computer Science',
    issuingOrganization: 'Tech University',
    issueDate: '2023-05-20',
    status: 'pending',
    fileUrl: 'https://placehold.co/600x400.png?text=Certificate1.pdf',
  },
  {
    id: 'cert2',
    studentId: 'student1',
    studentEmail: 'student@example.com',
    certificateName: 'Advanced Blockchain Development',
    issuingOrganization: 'Crypto Institute',
    issueDate: '2024-01-15',
    status: 'verified',
    fileUrl: 'https://placehold.co/600x400.png?text=Certificate2.pdf',
    blockchainHash: '0xabc123def45678901234567890abcdef',
    qrCodeData: '0xabc123def45678901234567890abcdef', // Now directly the hash
    verifiedBy: 'uni1',
    verificationTimestamp: new Date().toISOString(),
    aiSuggestions: 'Consider checking accreditation of Crypto Institute.'
  },
   {
    id: 'cert3',
    studentId: 'anotherStudent',
    studentEmail: 'another@example.com',
    certificateName: 'Introduction to AI',
    issuingOrganization: 'AI Academy',
    issueDate: '2023-11-10',
    status: 'pending',
    fileUrl: 'https://placehold.co/600x400.png?text=Certificate3.pdf',
  },
];

export const CertificateProvider = ({ children }: { children: ReactNode }) => {
  const [certificates, setCertificates] = useState<Certificate[]>(initialCertificates);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const addCertificate = async (data: Omit<Certificate, 'id' | 'status' | 'studentId' | 'studentEmail'>) => {
    if (!user || user.role !== 'student') {
      toast({ title: "Error", description: "Only students can upload certificates.", variant: "destructive" });
      return;
    }
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API call
    const newCertificate: Certificate = {
      ...data,
      id: `cert-${Date.now()}`,
      studentId: user.id,
      studentEmail: user.email,
      status: 'pending',
      fileUrl: data.fileUrl || `https://placehold.co/600x400.png?text=${encodeURIComponent(data.certificateName)}.pdf`,
    };
    setCertificates(prev => [...prev, newCertificate]);
    toast({ title: "Success", description: "Certificate uploaded successfully." });
    setLoading(false);
  };

  const updateCertificateStatus = async (id: string, status: CertificateStatus, verificationNotes?: string, aiSuggestions?: string) => {
     if (!user || user.role !== 'university') {
      toast({ title: "Error", description: "Only universities can verify certificates.", variant: "destructive" });
      return;
    }
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    setCertificates(prev =>
      prev.map(cert => {
        if (cert.id === id) {
          // Start with a copy of the existing certificate
          let modifiableCert = { ...cert };

          // Update common fields based on the action
          modifiableCert.status = status;
          // Preserve existing notes if new ones aren't provided, especially for rejections. Clear if not relevant.
          modifiableCert.verificationNotes = verificationNotes !== undefined ? verificationNotes : (status === 'rejected' ? modifiableCert.verificationNotes : undefined);
          modifiableCert.verifiedBy = user?.id; // University user ID performing the action
          modifiableCert.verificationTimestamp = new Date().toISOString(); // Timestamp of this status update
          // Preserve existing AI suggestions if new ones aren't provided
          modifiableCert.aiSuggestions = aiSuggestions !== undefined ? aiSuggestions : modifiableCert.aiSuggestions;

          if (status === 'verified') {
            const newBlockchainHash = `0x${Math.random().toString(16).slice(2,12)}${Math.random().toString(16).slice(2,12)}${Math.random().toString(16).slice(2,12)}`; // Made hash a bit longer for mock
            modifiableCert.blockchainHash = newBlockchainHash;
            modifiableCert.qrCodeData = newBlockchainHash; // QR Code data is now just the hash
          } else {
            // Explicitly set to undefined for non-verified statuses to ensure removal from the object
            modifiableCert.blockchainHash = undefined;
            modifiableCert.qrCodeData = undefined;
            
            // If status is being set to 'pending' (e.g., reset), clear most verification-specific details
            if (status === 'pending') {
                modifiableCert.verificationNotes = undefined;
                modifiableCert.verifiedBy = undefined;
                modifiableCert.verificationTimestamp = undefined;
                // Optionally clear AI suggestions too if resetting to pending:
                // modifiableCert.aiSuggestions = undefined;
            }
          }
          return modifiableCert as Certificate; // Ensure the returned object matches the Certificate type
        }
        return cert;
      })
    );
    toast({ title: "Success", description: `Certificate status updated to ${status}.` });
    setLoading(false);
  };
  
  const getCertificateById = (id: string) => certificates.find(cert => cert.id === id);
  const getCertificatesByStudent = (studentId: string) => certificates.filter(cert => cert.studentId === studentId);
  const getPendingCertificates = () => certificates.filter(cert => cert.status === 'pending');


  return (
    <CertificateContext.Provider value={{ certificates, loading, addCertificate, updateCertificateStatus, getCertificateById, getCertificatesByStudent, getPendingCertificates }}>
      {children}
    </CertificateContext.Provider>
  );
};

export const useCertificates = () => {
  const context = useContext(CertificateContext);
  if (context === undefined) {
    throw new Error('useCertificates must be used within a CertificateProvider');
  }
  return context;
};

