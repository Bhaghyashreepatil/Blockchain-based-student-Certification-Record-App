import { ReactNode } from 'react';
import { Logo } from '@/components/shared/Logo';
import Image from 'next/image';

export default function AuthLayout({ children, title, description }: { children: ReactNode; title: string; description: string }) {
  return (
    <div className="min-h-screen flex flex-col lg:flex-row items-center justify-center bg-gradient-to-br from-background to-indigo-100 p-4">
      <div className="lg:w-1/2 flex flex-col items-center justify-center p-8 lg:p-12 text-center lg:text-left">
        <div className="mb-8">
          <Logo size="lg" />
        </div>
        <h1 className="font-headline text-4xl lg:text-5xl font-bold text-primary mb-4">
          Secure Your Achievements
        </h1>
        <p className="text-lg text-foreground/80 mb-8 max-w-md">
          Join BlockCertify to manage, verify, and showcase your certifications with cutting-edge security and ease.
        </p>
        <Image 
          src="https://placehold.co/500x300.png" 
          alt="Blockchain illustration" 
          width={500} 
          height={300} 
          className="rounded-lg shadow-xl"
          data-ai-hint="blockchain security" 
        />
      </div>
      <div className="w-full max-w-md lg:w-1/2 p-4 lg:p-8">
        <Card className="shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl font-headline text-center text-primary">{title}</CardTitle>
            {description && <CardDescription className="text-center">{description}</CardDescription>}
          </CardHeader>
          <CardContent>
            {children}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Minimal Card components to avoid circular dependency if AuthLayout is used broadly.
// Usually, these would be imported from '@/components/ui/card'
const Card = ({ className, children }: { className?: string; children: ReactNode }) => (
  <div className={`rounded-xl border bg-card text-card-foreground shadow-sm ${className}`}>{children}</div>
);
const CardHeader = ({ className, children }: { className?: string; children: ReactNode }) => (
  <div className={`flex flex-col space-y-1.5 p-6 ${className}`}>{children}</div>
);
const CardTitle = ({ className, children }: { className?: string; children: ReactNode }) => (
  <div className={`text-2xl font-semibold leading-none tracking-tight ${className}`}>{children}</div>
);
const CardDescription = ({ className, children }: { className?: string; children: ReactNode }) => (
  <div className={`text-sm text-muted-foreground ${className}`}>{children}</div>
);
const CardContent = ({ className, children }: { className?: string; children: ReactNode }) => (
  <div className={`p-6 pt-0 ${className}`}>{children}</div>
);
