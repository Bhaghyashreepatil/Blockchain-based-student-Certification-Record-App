import { ShieldCheck } from 'lucide-react';
import Link from 'next/link';

export function Logo({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const textSize = size === 'lg' ? 'text-3xl' : size === 'md' ? 'text-2xl' : 'text-xl';
  const iconSize = size === 'lg' ? 8 : size === 'md' ? 6 : 5;

  return (
    <Link href="/" className="flex items-center gap-2 group">
      <ShieldCheck className={`h-${iconSize} w-${iconSize} text-primary group-hover:text-accent transition-colors`} />
      <span className={`font-headline font-semibold ${textSize} text-primary group-hover:text-accent transition-colors`}>
        BlockCertify
      </span>
    </Link>
  );
}
