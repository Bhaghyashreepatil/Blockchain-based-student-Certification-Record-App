"use client";

import { useState } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useCertificates } from '@/contexts/CertificateContext';
import { UploadCloud } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const certificateSchema = z.object({
  certificateName: z.string().min(3, "Certificate name must be at least 3 characters"),
  issuingOrganization: z.string().min(3, "Issuing organization must be at least 3 characters"),
  issueDate: z.string().refine((date) => !isNaN(Date.parse(date)), "Invalid date format"),
  // file: typeof window === 'undefined' ? z.any() : z.instanceof(FileList).refine(files => files?.length > 0, "Certificate file is required."),
  file: z.any().refine(files => files?.length > 0, "Certificate file is required."),
});

type CertificateFormData = z.infer<typeof certificateSchema>;

export default function CertificateForm() {
  const { addCertificate, loading } = useCertificates();
  const { toast } = useToast();
  const [fileName, setFileName] = useState<string | null>(null);

  const { register, handleSubmit, formState: { errors }, reset } = useForm<CertificateFormData>({
    resolver: zodResolver(certificateSchema),
  });

  const onSubmit: SubmitHandler<CertificateFormData> = async (data) => {
    // In a real app, you'd upload the file and get a URL. Here, we mock it.
    const mockFileUrl = `https://placehold.co/600x400.png?text=${encodeURIComponent(data.certificateName)}.pdf`;
    
    await addCertificate({
      certificateName: data.certificateName,
      issuingOrganization: data.issuingOrganization,
      issueDate: data.issueDate,
      fileUrl: mockFileUrl, // This would be the actual URL from storage
    });
    reset();
    setFileName(null);
    toast({ title: "Upload Queued", description: "Your certificate is being processed." });
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      setFileName(event.target.files[0].name);
    } else {
      setFileName(null);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl font-headline text-primary">Upload Certificate</CardTitle>
        <CardDescription>Fill in the details of your certificate to add it to the platform.</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit(onSubmit)}>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="certificateName">Certificate Name</Label>
            <Input id="certificateName" {...register("certificateName")} className="mt-1" />
            {errors.certificateName && <p className="text-sm text-destructive mt-1">{errors.certificateName.message}</p>}
          </div>

          <div>
            <Label htmlFor="issuingOrganization">Issuing Organization</Label>
            <Input id="issuingOrganization" {...register("issuingOrganization")} className="mt-1" />
            {errors.issuingOrganization && <p className="text-sm text-destructive mt-1">{errors.issuingOrganization.message}</p>}
          </div>

          <div>
            <Label htmlFor="issueDate">Issue Date</Label>
            <Input id="issueDate" type="date" {...register("issueDate")} className="mt-1" />
            {errors.issueDate && <p className="text-sm text-destructive mt-1">{errors.issueDate.message}</p>}
          </div>

          <div>
            <Label htmlFor="file">Certificate File (PDF, JPG, PNG)</Label>
            <Input 
              id="file" 
              type="file" 
              accept=".pdf,.jpg,.jpeg,.png" 
              {...register("file")} 
              className="mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
              onChange={(e) => {
                register("file").onChange(e); // Ensure react-hook-form's onChange is called
                handleFileChange(e);
              }}
            />
            {fileName && <p className="text-sm text-muted-foreground mt-1">Selected file: {fileName}</p>}
            {errors.file && <p className="text-sm text-destructive mt-1">{errors.file.message as string}</p>}
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : <UploadCloud className="mr-2 h-5 w-5" />}
            Upload Certificate
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
