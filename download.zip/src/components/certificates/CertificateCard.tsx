
"use client";

import type { Certificate, Role } from '@/types';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Badge } from "@/components/ui/badge";
import Link from 'next/link';
import Image from 'next/image';
import { FileText, CheckCircle, AlertTriangle, Clock, Eye, QrCode as QrCodeIcon } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import QRCode from 'qrcode.react';


const StatusBadge = ({ status }: { status: Certificate['status'] }) => {
  switch (status) {
    case 'verified':
      return <Badge variant="default" className="bg-green-500 hover:bg-green-600 text-white"><CheckCircle className="mr-1 h-4 w-4" />Verified</Badge>;
    case 'pending':
      return <Badge variant="secondary" className="bg-yellow-500 hover:bg-yellow-600 text-white"><Clock className="mr-1 h-4 w-4" />Pending</Badge>;
    case 'rejected':
      return <Badge variant="destructive"><AlertTriangle className="mr-1 h-4 w-4" />Rejected</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

interface CertificateCardProps {
  certificate: Certificate;
  onVerifyClick?: (certificateId: string) => void; // For university role
}

export default function CertificateCard({ certificate, onVerifyClick }: CertificateCardProps) {
  const { user } = useAuth();

  return (
    <Card className="flex flex-col justify-between shadow-lg hover:shadow-xl transition-shadow duration-300">
      <CardHeader>
        <div className="flex justify-between items-start">
          <FileText className="h-10 w-10 text-primary mb-2" />
          <StatusBadge status={certificate.status} />
        </div>
        <CardTitle className="text-xl font-headline leading-tight truncate" title={certificate.certificateName}>{certificate.certificateName}</CardTitle>
        <CardDescription className="truncate" title={certificate.issuingOrganization}>Issued by: {certificate.issuingOrganization}</CardDescription>
        <CardDescription>Date: {new Date(certificate.issueDate).toLocaleDateString()}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        {certificate.fileUrl && (
           <div className="aspect-[16/9] bg-muted rounded-md overflow-hidden mb-4 relative">
            <Image 
              src={certificate.fileUrl} 
              alt={certificate.certificateName} 
              layout="fill" 
              objectFit="contain"
              data-ai-hint="certificate document"
            />
          </div>
        )}
        {certificate.status === 'verified' && certificate.qrCodeData && (
          <div className="mt-4 p-2 bg-gray-100 rounded-md inline-block">
            <QRCode value={certificate.qrCodeData} size={80} level="H" />
            <p className="text-xs text-center mt-1 text-muted-foreground">Scan for Hash</p>
          </div>
        )}
         {user?.role === 'student' && certificate.status === 'rejected' && certificate.verificationNotes && (
          <div className="mt-2 p-2 border border-destructive/50 rounded-md bg-destructive/10">
            <p className="text-xs text-destructive font-semibold">Verification Notes:</p>
            <p className="text-xs text-destructive/80">{certificate.verificationNotes}</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row justify-between gap-2 items-stretch sm:items-center">
        {user?.role === 'university' && certificate.status === 'pending' && onVerifyClick && (
          <Button size="sm" onClick={() => onVerifyClick(certificate.id)} className="w-full sm:w-auto">
            <Eye className="mr-2 h-4 w-4" /> Review & Verify
          </Button>
        )}
        
        {user?.role === 'student' && (
           <Button variant="outline" size="sm" className="w-full" asChild>
            <Link href={`/student/certificates/${certificate.id}`}>
              <Eye className="mr-2 h-4 w-4" /> View Details
            </Link>
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}

