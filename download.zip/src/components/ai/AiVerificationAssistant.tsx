"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Wand2, Sparkles } from 'lucide-react';
import { verifyCertificate, type VerifyCertificateInput, type VerifyCertificateOutput } from '@/ai/flows/certificate-verification-ai-assist';
import { useToast } from '@/hooks/use-toast';

interface AiVerificationAssistantProps {
  certificateName: string;
  issuingOrganization: string;
  onSuggestions: (suggestions: string) => void; // Callback to pass suggestions to parent
}

export default function AiVerificationAssistant({ certificateName, issuingOrganization, onSuggestions }: AiVerificationAssistantProps) {
  const [customDetails, setCustomDetails] = useState('');
  const [suggestions, setSuggestions] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const defaultDetails = `Certificate: ${certificateName}, Issued by: ${issuingOrganization}.`;

  const handleGetSuggestions = async () => {
    setLoading(true);
    setSuggestions('');
    
    const inputDetails = customDetails.trim() !== '' ? customDetails : defaultDetails;

    try {
      const input: VerifyCertificateInput = { certificateDetails: inputDetails };
      const output: VerifyCertificateOutput = await verifyCertificate(input);
      setSuggestions(output.suggestedInformation);
      onSuggestions(output.suggestedInformation); // Pass to parent
      toast({ title: "AI Suggestions Received", description: "Review the suggestions below." });
    } catch (error) {
      console.error("AI Verification Error:", error);
      toast({ title: "AI Error", description: "Could not retrieve AI suggestions.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="shadow-md border-accent/50">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Wand2 className="h-6 w-6 text-accent" />
          <CardTitle className="text-xl font-headline text-accent">AI Verification Assistant</CardTitle>
        </div>
        <CardDescription>Get AI-powered suggestions for verifying this certificate based on trusted online sources.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="customDetails">Additional Certificate Details (Optional)</Label>
          <Textarea
            id="customDetails"
            value={customDetails}
            onChange={(e) => setCustomDetails(e.target.value)}
            placeholder={`e.g., Accreditation numbers, specific course codes. Default: ${defaultDetails}`}
            className="mt-1 min-h-[80px]"
          />
          <p className="text-xs text-muted-foreground mt-1">Provide any extra details, or leave blank to use default info.</p>
        </div>
        <Button onClick={handleGetSuggestions} disabled={loading} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
          {loading ? (
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : <Sparkles className="mr-2 h-5 w-5" /> }
          Get AI Suggestions
        </Button>
        {suggestions && (
          <div className="mt-4 p-4 bg-primary/5 border border-primary/20 rounded-md">
            <h4 className="font-semibold text-primary mb-2">AI Suggestions:</h4>
            <p className="text-sm whitespace-pre-wrap">{suggestions}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
