
export type Role = 'student' | 'university';

export interface User {
  id: string;
  email: string;
  role: Role;
  name?: string; // Optional: for display name
}

export type CertificateStatus = 'pending' | 'verified' | 'rejected';

export interface Certificate {
  id: string;
  studentId: string; // ID of the student who uploaded
  studentEmail: string; // Email of the student
  certificateName: string;
  issuingOrganization: string;
  issueDate: string; // Consider using Date type or ISO string
  fileUrl?: string; // URL to the uploaded file (mocked for now)
  status: CertificateStatus;
  qrCodeData?: string; // Data embedded in QR code (e.g., verification link or ID, now includes hash)
  blockchainHash?: string; // Hash of the certificate data
  verificationNotes?: string; // Notes from the university verifier
  aiSuggestions?: string; // Suggestions from AI verification assistant
  verifiedBy?: string; // University user ID who verified
  verificationTimestamp?: string; // ISO string
}
