
"use client";

import ProtectedPage from '@/components/protected/ProtectedPage';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { useCertificates } from '@/contexts/CertificateContext';
import { ListChecks, CheckSquare, Users } from 'lucide-react'; 

export default function UniversityDashboardPage() {
  const { user } = useAuth();
  const { certificates, getPendingCertificates } = useCertificates();
  
  const pendingCertificates = getPendingCertificates();
  const verifiedCount = certificates.filter(c => c.status === 'verified' && c.verifiedBy === user?.id).length; 
  const totalProcessed = certificates.filter(c => c.verifiedBy === user?.id).length; 

  return (
    <ProtectedPage allowedRoles={['university']}>
      <div className="space-y-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-3xl font-headline">Welcome, {user?.name || user?.email}!</CardTitle>
            <CardDescription>This is your university dashboard. Manage and verify student certificates.</CardDescription>
          </CardHeader>
        </Card>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Verifications</CardTitle>
              <ListChecks className="h-5 w-5 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{pendingCertificates.length}</div>
              <p className="text-xs text-muted-foreground">Certificates awaiting your review</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Certificates Verified by You</CardTitle>
              <CheckSquare className="h-5 w-5 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{verifiedCount}</div>
              <p className="text-xs text-muted-foreground">Successfully verified by your account</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Processed by You</CardTitle>
              <Users className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalProcessed}</div>
              <p className="text-xs text-muted-foreground">Total certificates reviewed by you</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-1 gap-4">
          <Link href="/university/pending" passHref>
            <Button className="w-full" size="lg">
              <ListChecks className="mr-2 h-5 w-5" /> View Pending Certificates
            </Button>
          </Link>
        </div>

      </div>
    </ProtectedPage>
  );
}

