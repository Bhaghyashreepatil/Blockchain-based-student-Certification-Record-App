"use client";

import ProtectedPage from '@/components/protected/ProtectedPage';
import { useCertificates } from '@/contexts/CertificateContext';
import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import type { Certificate } from '@/types';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowLeft, CheckCircle, XCircle, FileText, User, Calendar, Building, Download, AlertTriangle, Info } from 'lucide-react';
import AiVerificationAssistant from '@/components/ai/AiVerificationAssistant';
import { useToast } from '@/hooks/use-toast';

export default function VerifyCertificatePage() {
  const { getCertificateById, updateCertificateStatus, loading: certLoading } = useCertificates();
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();

  const certificateId = typeof params.id === 'string' ? params.id : '';
  const [certificate, setCertificate] = useState<Certificate | null>(null);
  const [verificationNotes, setVerificationNotes] = useState('');
  const [aiSuggestions, setAiSuggestions] = useState(''); // Store AI suggestions here

  useEffect(() => {
    if (certificateId) {
      const cert = getCertificateById(certificateId);
      if (cert) {
        setCertificate(cert);
        // Pre-fill notes if certificate was previously rejected and has notes
        if (cert.status === 'rejected' && cert.verificationNotes) {
          setVerificationNotes(cert.verificationNotes);
        }
         if (cert.aiSuggestions) {
          setAiSuggestions(cert.aiSuggestions);
        }
      }
    }
  }, [certificateId, getCertificateById]);

  const handleUpdateStatus = async (status: 'verified' | 'rejected') => {
    if (!certificate) return;
    // For rejected status, notes are required
    if (status === 'rejected' && verificationNotes.trim() === '') {
        toast({
            title: "Verification Notes Required",
            description: "Please provide a reason for rejecting the certificate.",
            variant: "destructive",
        });
        return;
    }
    await updateCertificateStatus(certificate.id, status, verificationNotes, aiSuggestions);
    router.push('/university/pending');
  };
  
  const handleAiSuggestions = (suggestions: string) => {
    setAiSuggestions(suggestions);
  };


  if (certLoading && !certificate) {
    return (
      <ProtectedPage allowedRoles={['university']}>
        <div className="flex justify-center items-center h-64">
         <svg className="animate-spin h-8 w-8 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        </div>
      </ProtectedPage>
    );
  }

  if (!certificate) {
    return (
      <ProtectedPage allowedRoles={['university']}>
        <div className="container mx-auto py-8 text-center">
          <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
          <h1 className="text-2xl font-semibold">Certificate Not Found</h1>
          <p className="text-muted-foreground">The certificate you are looking for does not exist or is not pending verification.</p>
           <Button onClick={() => router.back()} className="mt-6">
            <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
          </Button>
        </div>
      </ProtectedPage>
    );
  }
  
  if (certificate.status !== 'pending') {
     return (
      <ProtectedPage allowedRoles={['university']}>
        <div className="container mx-auto py-8 text-center">
          <Info className="mx-auto h-12 w-12 text-blue-500 mb-4" />
          <h1 className="text-2xl font-semibold">Certificate Already Processed</h1>
          <p className="text-muted-foreground">This certificate has already been {certificate.status}. No further action required.</p>
           <Button onClick={() => router.push('/university/pending')} className="mt-6">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Pending List
          </Button>
        </div>
      </ProtectedPage>
    );
  }


  return (
    <ProtectedPage allowedRoles={['university']}>
      <div className="container mx-auto py-8">
        <Button onClick={() => router.back()} variant="outline" className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Pending List
        </Button>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="shadow-xl">
              <CardHeader className="bg-primary/10">
                <div className="flex items-center gap-2">
                  <FileText className="h-8 w-8 text-primary" />
                  <CardTitle className="text-2xl font-headline text-primary">{certificate.certificateName}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground flex items-center"><User className="mr-2 h-4 w-4" />Student Email</p>
                    <p className="font-medium">{certificate.studentEmail}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground flex items-center"><Building className="mr-2 h-4 w-4" />Issuing Organization</p>
                    <p className="font-medium">{certificate.issuingOrganization}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground flex items-center"><Calendar className="mr-2 h-4 w-4" />Issue Date</p>
                    <p className="font-medium">{new Date(certificate.issueDate).toLocaleDateString()}</p>
                  </div>
                </div>

                {certificate.fileUrl && (
                  <div>
                    <h3 className="font-semibold text-lg mb-2">Certificate Document</h3>
                    <div className="aspect-[16/9] bg-muted rounded-lg overflow-hidden relative border">
                      <Image src={certificate.fileUrl} alt={certificate.certificateName} layout="fill" objectFit="contain" data-ai-hint="certificate document preview" />
                    </div>
                    {/* <Button variant="outline" className="w-full mt-2" asChild disabled={!certificate.fileUrl}>
                      <a href={certificate.fileUrl || '#'} target="_blank" rel="noopener noreferrer">
                        <Download className="mr-2 h-4 w-4" /> View/Download Document
                      </a>
                    </Button> */}
                  </div>
                )}
                
                <div>
                  <Label htmlFor="verificationNotes">Verification Notes (Required if rejecting)</Label>
                  <Textarea
                    id="verificationNotes"
                    value={verificationNotes}
                    onChange={(e) => setVerificationNotes(e.target.value)}
                    placeholder="Add any notes regarding the verification process..."
                    className="mt-1 min-h-[100px]"
                  />
                </div>

              </CardContent>
              <CardFooter className="flex flex-col sm:flex-row justify-end gap-3 p-6">
                <Button variant="destructive" onClick={() => handleUpdateStatus('rejected')} disabled={certLoading} className="w-full sm:w-auto">
                  <XCircle className="mr-2 h-5 w-5" /> Reject
                </Button>
                <Button onClick={() => handleUpdateStatus('verified')} disabled={certLoading} className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white">
                  <CheckCircle className="mr-2 h-5 w-5" /> Approve & Verify
                </Button>
              </CardFooter>
            </Card>
          </div>

          <div className="lg:col-span-1">
            <AiVerificationAssistant
              certificateName={certificate.certificateName}
              issuingOrganization={certificate.issuingOrganization}
              onSuggestions={handleAiSuggestions}
            />
          </div>
        </div>
      </div>
    </ProtectedPage>
  );
}
