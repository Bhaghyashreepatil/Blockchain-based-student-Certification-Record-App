"use client";

import ProtectedPage from '@/components/protected/ProtectedPage';
import CertificateCard from '@/components/certificates/CertificateCard';
import { useCertificates } from '@/contexts/CertificateContext';
import { useRouter } from 'next/navigation';
import { FileWarning } from 'lucide-react';

export default function PendingCertificatesPage() {
  const { getPendingCertificates, loading } = useCertificates();
  const router = useRouter();

  const pendingCertificates = getPendingCertificates();

  const handleVerifyClick = (certificateId: string) => {
    router.push(`/university/verify/${certificateId}`);
  };
  
  if (loading) {
    return (
      <ProtectedPage allowedRoles={['university']}>
        <div className="flex justify-center items-center h-64">
          <svg className="animate-spin h-8 w-8 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        </div>
      </ProtectedPage>
    );
  }


  return (
    <ProtectedPage allowedRoles={['university']}>
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-headline text-primary mb-8">Pending Certificate Verifications</h1>
        {pendingCertificates.length === 0 ? (
          <div className="text-center py-20 bg-card rounded-lg shadow-md">
            <FileWarning className="mx-auto h-16 w-16 text-muted-foreground mb-6" />
            <h2 className="text-2xl font-semibold mb-2">No Pending Certificates</h2>
            <p className="text-muted-foreground">There are currently no certificates awaiting verification.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pendingCertificates.map((cert) => (
              <CertificateCard 
                key={cert.id} 
                certificate={cert} 
                onVerifyClick={handleVerifyClick} 
              />
            ))}
          </div>
        )}
      </div>
    </ProtectedPage>
  );
}
