"use client";

import ProtectedPage from '@/components/protected/ProtectedPage';
import CertificateForm from '@/components/certificates/CertificateForm';

export default function UploadCertificatePage() {
  return (
    <ProtectedPage allowedRoles={['student']}>
      <div className="container mx-auto py-8">
        <CertificateForm />
      </div>
    </ProtectedPage>
  );
}
