"use client";

import ProtectedPage from '@/components/protected/ProtectedPage';
import CertificateCard from '@/components/certificates/CertificateCard';
import { useAuth } from '@/contexts/AuthContext';
import { useCertificates } from '@/contexts/CertificateContext';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { UploadCloud, FileWarning } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Certificate } from '@/types';

export default function MyCertificatesPage() {
  const { user } = useAuth();
  const { getCertificatesByStudent, loading } = useCertificates();

  if (loading && !user) {
    return (
      <ProtectedPage allowedRoles={['student']}>
        <div className="flex justify-center items-center h-64">
          <svg className="animate-spin h-8 w-8 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        </div>
      </ProtectedPage>
    );
  }
  
  const certificates = user ? getCertificatesByStudent(user.id) : [];

  const categorizedCertificates = {
    all: certificates,
    pending: certificates.filter(c => c.status === 'pending'),
    verified: certificates.filter(c => c.status === 'verified'),
    rejected: certificates.filter(c => c.status === 'rejected'),
  };

  const renderCertificateList = (certs: Certificate[]) => {
    if (certs.length === 0) {
      return (
        <div className="text-center py-10">
          <FileWarning className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <p className="text-muted-foreground">No certificates in this category.</p>
        </div>
      );
    }
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        {certs.map((cert) => (
          <CertificateCard key={cert.id} certificate={cert} />
        ))}
      </div>
    );
  };

  return (
    <ProtectedPage allowedRoles={['student']}>
      <div className="container mx-auto py-8">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
          <h1 className="text-3xl font-headline text-primary">My Certificates</h1>
          <Link href="/student/upload" passHref>
            <Button>
              <UploadCloud className="mr-2 h-5 w-5" /> Upload New Certificate
            </Button>
          </Link>
        </div>

        {certificates.length === 0 && !loading ? (
          <div className="text-center py-20 bg-card rounded-lg shadow-md">
            <FileWarning className="mx-auto h-16 w-16 text-muted-foreground mb-6" />
            <h2 className="text-2xl font-semibold mb-2">No Certificates Yet</h2>
            <p className="text-muted-foreground mb-6">You haven&apos;t uploaded any certificates. Start by uploading your first one!</p>
            <Link href="/student/upload" passHref>
              <Button size="lg">
                <UploadCloud className="mr-2 h-5 w-5" /> Upload Certificate
              </Button>
            </Link>
          </div>
        ) : (
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
              <TabsTrigger value="all">All ({categorizedCertificates.all.length})</TabsTrigger>
              <TabsTrigger value="pending">Pending ({categorizedCertificates.pending.length})</TabsTrigger>
              <TabsTrigger value="verified">Verified ({categorizedCertificates.verified.length})</TabsTrigger>
              <TabsTrigger value="rejected">Rejected ({categorizedCertificates.rejected.length})</TabsTrigger>
            </TabsList>
            <TabsContent value="all">{renderCertificateList(categorizedCertificates.all)}</TabsContent>
            <TabsContent value="pending">{renderCertificateList(categorizedCertificates.pending)}</TabsContent>
            <TabsContent value="verified">{renderCertificateList(categorizedCertificates.verified)}</TabsContent>
            <TabsContent value="rejected">{renderCertificateList(categorizedCertificates.rejected)}</TabsContent>
          </Tabs>
        )}
      </div>
    </ProtectedPage>
  );
}
