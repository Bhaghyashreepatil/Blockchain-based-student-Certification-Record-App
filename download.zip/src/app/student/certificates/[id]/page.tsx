
"use client";

import ProtectedPage from '@/components/protected/ProtectedPage';
import { useCertificates } from '@/contexts/CertificateContext';
import { useAuth } from '@/contexts/AuthContext';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowLeft, CheckCircle, AlertTriangle, Clock, QrCode as QrCodeIcon, Hash, UserCheck, CalendarDays, Info } from 'lucide-react';
import QRCode from 'qrcode.react';

const StatusInfo = ({ status, notes, verifiedBy, verificationTimestamp }: { status: string, notes?: string, verifiedBy?: string, verificationTimestamp?: string }) => {
  let icon, colorClass, text;

  switch (status) {
    case 'verified':
      icon = <CheckCircle className="h-5 w-5 text-green-500" />;
      colorClass = 'text-green-700 bg-green-50 border-green-200';
      text = 'This certificate has been successfully verified.';
      break;
    case 'pending':
      icon = <Clock className="h-5 w-5 text-yellow-500" />;
      colorClass = 'text-yellow-700 bg-yellow-50 border-yellow-200';
      text = 'This certificate is currently awaiting verification.';
      break;
    case 'rejected':
      icon = <AlertTriangle className="h-5 w-5 text-red-500" />;
      colorClass = 'text-red-700 bg-red-50 border-red-200';
      text = 'This certificate was rejected.';
      break;
    default:
      icon = <Info className="h-5 w-5 text-gray-500" />;
      colorClass = 'text-gray-700 bg-gray-50 border-gray-200';
      text = 'Status unknown.';
  }

  return (
    <div className={`p-4 rounded-md border ${colorClass} flex items-start gap-3`}>
      {icon}
      <div>
        <p className="font-semibold">{text}</p>
        {status === 'rejected' && notes && <p className="text-sm mt-1">Reason: {notes}</p>}
        {status === 'verified' && verifiedBy && verificationTimestamp && (
          <p className="text-sm mt-1">
            Verified by university official (ID: {verifiedBy}) on {new Date(verificationTimestamp).toLocaleDateString()}.
          </p>
        )}
      </div>
    </div>
  );
};


export default function StudentCertificateDetailPage() {
  const { getCertificateById } = useCertificates();
  const { user } = useAuth();
  const params = useParams();
  const router = useRouter();
  const certificateId = typeof params.id === 'string' ? params.id : '';
  
  const certificate = getCertificateById(certificateId);

  if (!certificate || certificate.studentId !== user?.id) {
    return (
      <ProtectedPage allowedRoles={['student']}>
        <div className="container mx-auto py-8 text-center">
          <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
          <h1 className="text-2xl font-semibold">Certificate Not Found</h1>
          <p className="text-muted-foreground">The certificate you are looking for does not exist or you do not have permission to view it.</p>
          <Button onClick={() => router.back()} className="mt-6">
            <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
          </Button>
        </div>
      </ProtectedPage>
    );
  }
  
  return (
    <ProtectedPage allowedRoles={['student']}>
      <div className="container mx-auto py-8">
        <Button onClick={() => router.back()} variant="outline" className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to My Certificates
        </Button>

        <Card className="shadow-xl overflow-hidden">
          <CardHeader className="bg-primary/10 p-6">
            <div className="flex justify-between items-center">
              <CardTitle className="text-3xl font-headline text-primary">{certificate.certificateName}</CardTitle>
              <Badge variant={certificate.status === 'verified' ? 'default' : certificate.status === 'rejected' ? 'destructive' : 'secondary'} className={
                certificate.status === 'verified' ? 'bg-green-500 text-white' : 
                certificate.status === 'rejected' ? '' : 
                'bg-yellow-500 text-white'
              }>
                {certificate.status.charAt(0).toUpperCase() + certificate.status.slice(1)}
              </Badge>
            </div>
            <CardDescription className="text-lg text-primary/80">Issued by: {certificate.issuingOrganization}</CardDescription>
          </CardHeader>
          <CardContent className="p-6 grid md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-6">
              <StatusInfo 
                status={certificate.status} 
                notes={certificate.verificationNotes} 
                verifiedBy={certificate.verifiedBy}
                verificationTimestamp={certificate.verificationTimestamp}
              />
              
              <div className="space-y-2">
                <h3 className="font-semibold text-lg text-foreground">Certificate Details</h3>
                <p><CalendarDays className="inline mr-2 h-4 w-4 text-muted-foreground" /><strong>Issue Date:</strong> {new Date(certificate.issueDate).toLocaleDateString()}</p>
                <p><UserCheck className="inline mr-2 h-4 w-4 text-muted-foreground" /><strong>Student Email:</strong> {certificate.studentEmail}</p>
              </div>

              {certificate.status === 'verified' && (
                <div className="space-y-2">
                  <h3 className="font-semibold text-lg text-foreground">Verification Proof</h3>
                  {certificate.blockchainHash && <p><Hash className="inline mr-2 h-4 w-4 text-muted-foreground" /><strong>Blockchain Hash:</strong> <span className="font-mono text-sm break-all">{certificate.blockchainHash}</span></p>}
                  {/* QR Data display removed as it's now same as blockchainHash and represented by the QR code itself */}
                  {certificate.aiSuggestions && (
                    <div className="p-3 bg-accent/10 rounded-md border border-accent/30">
                      <p className="text-sm font-semibold text-accent-foreground mb-1">AI Verification Insights (for university):</p>
                      <p className="text-xs text-accent-foreground/80">{certificate.aiSuggestions}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
            <div className="md:col-span-1 space-y-6">
              {certificate.fileUrl && (
                <div>
                  <h3 className="font-semibold text-lg text-foreground mb-2">Certificate Document</h3>
                  <div className="aspect-video bg-muted rounded-lg overflow-hidden relative border">
                    <Image src={certificate.fileUrl} alt={certificate.certificateName} layout="fill" objectFit="contain" data-ai-hint="document preview"/>
                  </div>
                </div>
              )}
              {certificate.status === 'verified' && certificate.qrCodeData && (
                <div>
                  <h3 className="font-semibold text-lg text-foreground mb-2">Verification QR Code (Hash)</h3>
                  <div className="p-4 bg-card border rounded-lg flex justify-center items-center">
                    <QRCode value={certificate.qrCodeData} size={160} level="H" />
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </ProtectedPage>
  );
}

