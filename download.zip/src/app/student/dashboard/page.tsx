"use client";

import ProtectedPage from '@/components/protected/ProtectedPage';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { useCertificates } from '@/contexts/CertificateContext';
import { FileText, UploadCloud, CheckCircle, AlertTriangle, Clock } from 'lucide-react';

export default function StudentDashboardPage() {
  const { user } = useAuth();
  const { getCertificatesByStudent } = useCertificates();
  
  const studentCertificates = user ? getCertificatesByStudent(user.id) : [];
  const pendingCount = studentCertificates.filter(c => c.status === 'pending').length;
  const verifiedCount = studentCertificates.filter(c => c.status === 'verified').length;
  const rejectedCount = studentCertificates.filter(c => c.status === 'rejected').length;

  return (
    <ProtectedPage allowedRoles={['student']}>
      <div className="space-y-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-3xl font-headline">Welcome, {user?.name || user?.email}!</CardTitle>
            <CardDescription>This is your student dashboard. Manage your certificates and track their verification status.</CardDescription>
          </CardHeader>
        </Card>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Certificates</CardTitle>
              <FileText className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{studentCertificates.length}</div>
              <p className="text-xs text-muted-foreground">Total certificates uploaded</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Verified</CardTitle>
              <CheckCircle className="h-5 w-5 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{verifiedCount}</div>
              <p className="text-xs text-muted-foreground">Certificates successfully verified</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <Clock className="h-5 w-5 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{pendingCount}</div>
              <p className="text-xs text-muted-foreground">Certificates awaiting verification</p>
            </CardContent>
          </Card>
        </div>

        {rejectedCount > 0 && (
           <Card className="border-destructive">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-destructive">Rejected Certificates</CardTitle>
              <AlertTriangle className="h-5 w-5 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{rejectedCount}</div>
              <p className="text-xs text-destructive/80">Certificates that were rejected. Check details in 'My Certificates'.</p>
            </CardContent>
          </Card>
        )}

        <div className="grid gap-4 md:grid-cols-2">
          <Link href="/student/upload" passHref>
            <Button className="w-full" size="lg">
              <UploadCloud className="mr-2 h-5 w-5" /> Upload New Certificate
            </Button>
          </Link>
          <Link href="/student/certificates" passHref>
            <Button variant="outline" className="w-full" size="lg">
              <FileText className="mr-2 h-5 w-5" /> View My Certificates
            </Button>
          </Link>
        </div>
      </div>
    </ProtectedPage>
  );
}
