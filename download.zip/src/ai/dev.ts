import { config } from 'dotenv';
config();

import '@/ai/flows/certificate-verification-ai-assist.ts';